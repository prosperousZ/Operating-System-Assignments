#include "types.h"
#include "stat.h"
#include "user.h"
#include "stddef.h"
int
main(int argc, char *argv[])
{
  wait2(NULL);
  printf(1, "this is test case for wait2. %d\n");
   
  exit2(0);

}
