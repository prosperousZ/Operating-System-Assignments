#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  //int number;
  //number = exit2(999);
  printf(1, "this is just a test case. %d\n" );
   
  exit2(0);

}
