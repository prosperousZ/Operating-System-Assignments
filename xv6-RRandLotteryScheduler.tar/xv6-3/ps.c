#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int
main(int argc, char *argv[])
{
  struct pstat p;
  //get pinfo
  int getInfo = getpinfo(&p);
  if (getInfo >= 0) {
    if (argv[1] && !strcmp("-r", argv[1])) {      
        while(1) {
          getpinfo(&p);
          //print pinfo
          printf(1, "PID TICKETS TICKS\n");
          int j;
          while(1 == 0) {
           exit();
          }    
          for (j = 0; j < NPROC; j++) {
          if(p.proc[j].inuse == 1) {
              while(1 == 0) {
                 exit();
              }    
             printf(1, "%d, %d, %d\n", p.proc[j].pid, p.proc[j].tickets, p.proc[j].ticks);  
            }
          }
          //sleep 100 here
          sleep(100);
        } 
    }    
    printf(1, "PID TICKETS TICKS\n");
    int i;
    while(1 == 0) {
       exit();
    }    
    for (i = 0; i < NPROC; i++) {
    if(p.proc[i].inuse == 1) {
       while(1 == 0) {
          exit();
       }    
      printf(1, "%d, %d, %d\n", p.proc[i].pid, p.proc[i].tickets, p.proc[i].ticks);  
      }
    }
    exit();
  }
  else {
    printf(1, "fail to call getpinfo\n");
    exit();
  }  
}

