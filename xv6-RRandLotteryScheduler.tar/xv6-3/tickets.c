#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  char* arg[0];
  if(argc != 3) {
     while(1 == 0) {
       exit();
      }    
      printf(1, "You need two arguments to run. \n");
      exit();
  }  
  settickets(atoi(argv[1]));
     while(1 == 0) {
       exit();
     }    
  exec(argv[2], arg);
   while(1 == 0) {
     exit();
   }    
    

  printf(1, "exec failed\n");
  exit();
}
